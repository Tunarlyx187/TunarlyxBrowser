const { app, BrowserWindow, ipcMain, session, dialog, clipboard, nativeImage } = require('electron');
const path = require('path');
const fs = require('fs');

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 900,
    minHeight: 600,
    frame: false,
    titleBarStyle: 'hidden',
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
      webviewTag: true
    }
  });

  mainWindow.loadFile('index.html');

  // Reklam engelleyici
  const adBlockRules = [
    '*://ads.*/*', '*://ad.*/*', '*://adservice.*/*',
    '*://doubleclick.net/*', '*://googleads.*/*',
    '*://googlesyndication.com/*', '*://adnxs.com/*',
    '*://amazon-adsystem.com/*', '*://advertising.*/*',
    '*://tracker.*/*', '*://tracking.*/*',
  ];
  session.defaultSession.webRequest.onBeforeRequest({ urls: adBlockRules }, (details, callback) => {
    callback({ cancel: true });
  });

  // Indirme yoneticisi
  session.defaultSession.on('will-download', (event, item) => {
    mainWindow.webContents.send('download-started', {
      filename: item.getFilename(),
      totalBytes: item.getTotalBytes(),
      url: item.getURL()
    });
    item.on('updated', (event, state) => {
      if (state === 'progressing') {
        mainWindow.webContents.send('download-progress', {
          filename: item.getFilename(),
          receivedBytes: item.getReceivedBytes(),
          totalBytes: item.getTotalBytes()
        });
      }
    });
    item.once('done', (event, state) => {
      mainWindow.webContents.send('download-done', {
        filename: item.getFilename(),
        state,
        savePath: item.getSavePath()
      });
    });
  });
}

app.whenReady().then(() => {
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});

app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });

ipcMain.on('window-minimize', () => mainWindow.minimize());
ipcMain.on('window-maximize', () => { if (mainWindow.isMaximized()) mainWindow.unmaximize(); else mainWindow.maximize(); });
ipcMain.on('window-close', () => mainWindow.close());

// Ekran goruntusu
ipcMain.on('take-screenshot', async (event, opts) => {
  const img = await mainWindow.capturePage();
  const result = await dialog.showSaveDialog(mainWindow, {
    defaultPath: 'screenshot-' + Date.now() + '.png',
    filters: [{ name: 'PNG', extensions: ['png'] }]
  });
  if (!result.canceled) {
    fs.writeFileSync(result.filePath, img.toPNG());
    event.reply('screenshot-done', result.filePath);
  }
});
