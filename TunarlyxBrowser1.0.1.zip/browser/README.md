# MyBrowser 🌐

Electron tabanlı kişisel masaüstü tarayıcı.

## Kurulum ve Çalıştırma

### Gereksinimler
- [Node.js](https://nodejs.org) (v18 veya üzeri)
- npm (Node ile birlikte gelir)

### Adımlar

1. Bu klasörü bir yere çıkar
2. Klasörü terminalde/komut satırında aç
3. Şu komutları sırayla çalıştır:

```bash
npm install
npm start
```

## EXE Oluşturma (Windows)

```bash
npm install
npm run dist
```

`dist/` klasöründe kurulum dosyası (`.exe`) oluşur.

---

## Özellikler

- 🗂 Sekmeli yapı (sınırsız sekme)
- 🔍 Adres çubuğu (URL veya arama)
- ⬅️ Geri / İleri / Yenile
- 🏠 Yeni sekme sayfası (kısayollar)
- ⌨️ Klavye kısayolları:
  - `Ctrl+T` → Yeni sekme
  - `Ctrl+W` → Sekmeyi kapat
  - `Ctrl+L` → Adres çubuğuna odaklan
  - `F5`     → Yenile
  - `Alt+←`  → Geri
  - `Alt+→`  → İleri

## Kısayolları Özelleştirme

`index.html` içinde `SHORTCUTS` dizisini düzenle:

```js
const SHORTCUTS = [
  { label: 'Google', url: 'https://www.google.com', icon: '🔍' },
  // istediğini ekle...
];
```
